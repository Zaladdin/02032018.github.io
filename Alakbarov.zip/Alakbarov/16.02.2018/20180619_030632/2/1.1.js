function f() {
  console.log('hello');
}

new f;