//  1
(() => {
    console.log("func");
})();


// 2
(func => func())(() => console.log("func2"));