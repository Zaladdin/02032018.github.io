
const step = (x, y) => x**y;

const stepPi = step.bind(null, Math.PI),
      stepE = step.bind(null, Math.E),
      stepnum = step.bind(null, 2);


console.log(stepPi(2));
console.log(stepE(2));
console.log(stepnum(2));

const stepchis = y => x => x**y; 
const kv = stepchis( 2); 
const kub = stepchis(3); 
const chet = stepchis(4); 
console.log(kv(3)); 
console.log(kub(3)); 
console.log(chet(3));