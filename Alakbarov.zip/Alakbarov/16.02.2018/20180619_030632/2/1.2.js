var xyz = {
    toString: function() {
         return 'hello';
    }
}

'' + xyz; 