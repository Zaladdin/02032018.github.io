const summ = (x, y) => y !== 0 ? 1 + summ(x, y - 1) : x;

console.log(summ(6, 66));