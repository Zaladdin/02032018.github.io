console.time("tri");
console.time("sem");
console.time("des");
setTimeout ( () => 
{
console.timeEnd("tri");
setTimeout( () => 
{
console.timeEnd("sem");
setTimeout( () => 
{
console.timeEnd("des");
		}, 10000);
	}, 7000);
}, 3000);