"use strict";


function rgb(color1 = 0, color2 = 0, color3 = 0) {
    return 'rgb(${color1}, ${color2}, ${color3})';
}

function genCol() {
    return Math.floor(Math.random() * 256);
}

console.log('rgb'(genCol(), genCol(), genCol()));