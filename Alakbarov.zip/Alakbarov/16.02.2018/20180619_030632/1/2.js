console.log('Hello, %s!', 'world');
