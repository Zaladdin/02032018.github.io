(function (){

    alert("(" + arguments.callee.toString() + ")()");

})();