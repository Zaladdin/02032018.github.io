const [a1, b1, c1, a2, b2, c2] = [1, 3, 2, 9, 2, 7];
let d1 = a1*b2-a2*b1;
let d2 = c1*b2-c2*b1;
let d3 = a1*c2-a2*c1;
let x1 = d2/d1;
let x2 = d3/d1;
console.log("x1="+x1);
console.log("x2="+x2);