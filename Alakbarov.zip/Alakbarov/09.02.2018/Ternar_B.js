const value = NaN ;
const ternB =   (value !== value) ? '=NaN'
: (value === null) ? '=null' 
:  (value === undefined) ? '=undefined' 
:   (value === 0) ? '=0'
:    (value === '') ? '=""' 
:     (value === false) ? '=false' 
:                                  "other";
console.log (ternB);