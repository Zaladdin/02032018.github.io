const age = 17;
const restricted = ( age < 18 ) ? 'yes' : 
( age === 18 ) ? 'notsure' : 'no';
console.log( restricted );