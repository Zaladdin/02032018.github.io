import mixin from './mixin';

console.log( 5::mixin() );